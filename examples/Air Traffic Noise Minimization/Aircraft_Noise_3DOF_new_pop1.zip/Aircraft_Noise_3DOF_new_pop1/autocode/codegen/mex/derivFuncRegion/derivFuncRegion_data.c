/*
 * derivFuncRegion_data.c
 *
 * Code generation for function 'derivFuncRegion_data'
 *
 * C source code generated on: Sat Jan 21 02:02:52 2017
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "derivFuncRegion.h"
#include "derivFuncRegion_data.h"

/* Variable Definitions */
emlrtRSInfo c_emlrtRSI = { 21, "computeControlUnconstrained",
  "/home/mall/mjgrant/trajProblems/Friends/Janav/Aircraft_Noise_3DOF_new_pop1/autocode/computeControlUnconstrained.m"
};

emlrtRSInfo nc_emlrtRSI = { 37, "mpower",
  "/apps/rhel6/MATLAB/R2013a/toolbox/eml/lib/matlab/ops/mpower.m" };

emlrtRSInfo oc_emlrtRSI = { 42, "power",
  "/apps/rhel6/MATLAB/R2013a/toolbox/eml/lib/matlab/ops/power.m" };

emlrtRSInfo pc_emlrtRSI = { 56, "power",
  "/apps/rhel6/MATLAB/R2013a/toolbox/eml/lib/matlab/ops/power.m" };

emlrtRSInfo qc_emlrtRSI = { 20, "eml_error",
  "/apps/rhel6/MATLAB/R2013a/toolbox/eml/lib/matlab/eml/eml_error.m" };

emlrtMCInfo emlrtMCI = { 21, 1, "computeControlUnconstrained",
  "/home/mall/mjgrant/trajProblems/Friends/Janav/Aircraft_Noise_3DOF_new_pop1/autocode/computeControlUnconstrained.m"
};

emlrtRTEInfo emlrtRTEI = { 1, 22, "derivFuncRegion",
  "/home/mall/mjgrant/trajProblems/Friends/Janav/Aircraft_Noise_3DOF_new_pop1/autocode/derivFuncRegion.m"
};

emlrtRTEInfo b_emlrtRTEI = { 20, 5, "eml_error",
  "/apps/rhel6/MATLAB/R2013a/toolbox/eml/lib/matlab/eml/eml_error.m" };

/* End of code generation (derivFuncRegion_data.c) */

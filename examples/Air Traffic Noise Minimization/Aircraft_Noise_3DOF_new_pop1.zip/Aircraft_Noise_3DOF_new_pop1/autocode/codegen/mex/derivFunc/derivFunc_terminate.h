/*
 * derivFunc_terminate.h
 *
 * Code generation for function 'derivFunc_terminate'
 *
 * C source code generated on: Sat Jan 21 02:02:06 2017
 *
 */

#ifndef __DERIVFUNC_TERMINATE_H__
#define __DERIVFUNC_TERMINATE_H__
/* Include files */
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "mwmathutil.h"

#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "blas.h"
#include "rtwtypes.h"
#include "derivFunc_types.h"

/* Function Declarations */
extern void derivFunc_atexit(void);
extern void derivFunc_terminate(void);
#endif
/* End of code generation (derivFunc_terminate.h) */

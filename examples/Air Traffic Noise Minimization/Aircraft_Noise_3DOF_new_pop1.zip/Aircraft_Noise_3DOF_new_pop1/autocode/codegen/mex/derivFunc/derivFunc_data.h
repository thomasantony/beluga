/*
 * derivFunc_data.h
 *
 * Code generation for function 'derivFunc_data'
 *
 * C source code generated on: Sat Jan 21 02:02:06 2017
 *
 */

#ifndef __DERIVFUNC_DATA_H__
#define __DERIVFUNC_DATA_H__
/* Include files */
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "mwmathutil.h"

#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "blas.h"
#include "rtwtypes.h"
#include "derivFunc_types.h"

/* Variable Declarations */
extern emlrtRSInfo c_emlrtRSI;
extern emlrtRSInfo nc_emlrtRSI;
extern emlrtRSInfo oc_emlrtRSI;
extern emlrtRSInfo pc_emlrtRSI;
extern emlrtRSInfo qc_emlrtRSI;
extern emlrtMCInfo emlrtMCI;
extern emlrtRTEInfo emlrtRTEI;
extern emlrtRTEInfo b_emlrtRTEI;
#endif
/* End of code generation (derivFunc_data.h) */

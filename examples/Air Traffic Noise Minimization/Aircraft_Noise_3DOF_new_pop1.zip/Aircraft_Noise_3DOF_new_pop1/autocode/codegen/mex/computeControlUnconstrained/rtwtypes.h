/*
 * rtwtypes.h
 *
 * Code generation for function 'computeControlUnconstrained'
 *
 * C source code generated on: Sat Jan 21 02:01:21 2017
 *
 */

#ifndef __RTWTYPES_H__
#define __RTWTYPES_H__
#include "tmwtypes.h"
/* 
 * TRUE/FALSE definitions
 */
#ifndef TRUE
#define TRUE (1U)
#endif 
#ifndef FALSE
#define FALSE (0U)
#endif 
#endif
/* End of code generation (rtwtypes.h) */

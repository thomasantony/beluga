/*
 * computeControlUnconstrained_data.h
 *
 * Code generation for function 'computeControlUnconstrained_data'
 *
 * C source code generated on: Sat Jan 21 02:01:19 2017
 *
 */

#ifndef __COMPUTECONTROLUNCONSTRAINED_DATA_H__
#define __COMPUTECONTROLUNCONSTRAINED_DATA_H__
/* Include files */
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "mwmathutil.h"

#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "blas.h"
#include "rtwtypes.h"
#include "computeControlUnconstrained_types.h"

/* Variable Declarations */
extern emlrtRSInfo nc_emlrtRSI;
extern emlrtRTEInfo emlrtRTEI;
#endif
/* End of code generation (computeControlUnconstrained_data.h) */

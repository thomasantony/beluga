/*
 * bc_data.c
 *
 * Code generation for function 'bc_data'
 *
 * C source code generated on: Sat Jan 21 02:03:41 2017
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "bc.h"
#include "bc_data.h"

/* Variable Definitions */
const volatile char_T *emlrtBreakCheckR2012bFlagVar;
emlrtRSInfo nc_emlrtRSI = { 37, "mpower",
  "/apps/rhel6/MATLAB/R2013a/toolbox/eml/lib/matlab/ops/mpower.m" };

emlrtRSInfo oc_emlrtRSI = { 42, "power",
  "/apps/rhel6/MATLAB/R2013a/toolbox/eml/lib/matlab/ops/power.m" };

emlrtRSInfo pc_emlrtRSI = { 56, "power",
  "/apps/rhel6/MATLAB/R2013a/toolbox/eml/lib/matlab/ops/power.m" };

emlrtRSInfo qc_emlrtRSI = { 20, "eml_error",
  "/apps/rhel6/MATLAB/R2013a/toolbox/eml/lib/matlab/eml/eml_error.m" };

emlrtRTEInfo emlrtRTEI = { 20, 5, "eml_error",
  "/apps/rhel6/MATLAB/R2013a/toolbox/eml/lib/matlab/eml/eml_error.m" };

/* End of code generation (bc_data.c) */

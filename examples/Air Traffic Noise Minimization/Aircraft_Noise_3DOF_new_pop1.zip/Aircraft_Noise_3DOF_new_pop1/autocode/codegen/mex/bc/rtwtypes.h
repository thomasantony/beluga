/*
 * rtwtypes.h
 *
 * Code generation for function 'bc'
 *
 * C source code generated on: Sat Jan 21 02:03:43 2017
 *
 */

#ifndef __RTWTYPES_H__
#define __RTWTYPES_H__
#include "tmwtypes.h"
/* 
 * TRUE/FALSE definitions
 */
#ifndef TRUE
#define TRUE (1U)
#endif 
#ifndef FALSE
#define FALSE (0U)
#endif 
#endif
/* End of code generation (rtwtypes.h) */

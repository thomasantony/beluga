/*
 * bc_data.h
 *
 * Code generation for function 'bc_data'
 *
 * C source code generated on: Sat Jan 21 02:03:41 2017
 *
 */

#ifndef __BC_DATA_H__
#define __BC_DATA_H__
/* Include files */
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "mwmathutil.h"

#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "blas.h"
#include "rtwtypes.h"
#include "bc_types.h"

/* Variable Declarations */
extern const volatile char_T *emlrtBreakCheckR2012bFlagVar;
extern emlrtRSInfo nc_emlrtRSI;
extern emlrtRSInfo oc_emlrtRSI;
extern emlrtRSInfo pc_emlrtRSI;
extern emlrtRSInfo qc_emlrtRSI;
extern emlrtRTEInfo emlrtRTEI;
#endif
/* End of code generation (bc_data.h) */

/*
 * bc_terminate.h
 *
 * Code generation for function 'bc_terminate'
 *
 * C source code generated on: Sat Jan 21 02:03:42 2017
 *
 */

#ifndef __BC_TERMINATE_H__
#define __BC_TERMINATE_H__
/* Include files */
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "mwmathutil.h"

#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "blas.h"
#include "rtwtypes.h"
#include "bc_types.h"

/* Function Declarations */
extern void bc_atexit(void);
extern void bc_terminate(void);
#endif
/* End of code generation (bc_terminate.h) */
